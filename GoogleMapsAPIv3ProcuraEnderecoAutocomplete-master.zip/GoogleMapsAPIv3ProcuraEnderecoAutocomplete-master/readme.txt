Google Maps API v3: Busca de endere�o e Autocomplete

Um pequeno projeto utilizando o Google Maps JavaScript API v3 e jQuery UI Autocomplete para obter a latitude e longitude a partir de um endere�o fornecido pelo usu�rio.

Demo: http://www.princiweb.com.br/demos/google-maps-api-v3-busca-endereco-autocomplete/

jQuery UI Autocomplete: http://jqueryui.com/demos/autocomplete/
Google Maps JavaScript API v3: https://developers.google.com/maps/documentation/javascript/